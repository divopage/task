<?php

return [
    [
        'username' => 'admin',
        'auth_key' => 'eckb2DLY9uv6r1hM6D73eoHPvv6BfnXc',
        'password_hash' => '$2y$13$D8areN6YSJh.fmR.Ww/sWOJ8EXRxNS9c7u7ubIrVozomTR8MY0PbO',
        'password_reset_token' => 't5GU9NwpuGYSfb7FEZMAxqtuz2PkEvv_' . time(),
        'email_confirm_token' => null,
        'created_at' => '1439635619',
        'updated_at' => '1439635619',
        'email' => 'admin@example.com',
        'role' => 'user',
        'status' => 1,
    ],
    [
        'username' => 'user',
        'auth_key' => 'eckb2DLY9uv6r1hM6D73eoHPvv6BfnXc',
        'password_hash' => '$2y$13$D8areN6YSJh.fmR.Ww/sWOJ8EXRxNS9c7u7ubIrVozomTR8MY0PbO',
        'password_reset_token' => null,
        'email_confirm_token' => null,
        'created_at' => '1439635619',
        'updated_at' => '1439635619',
        'email' => 'user@example.com',
        'role' => 'user',
        'status' => 0,
    ],
];
