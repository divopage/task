<?php

return [
    'NAV_HOME' => 'Главная',
    'NAV_CONTACT' => 'Связь',
    'NAV_SIGNUP' => 'Регистрация',
    'NAV_LOGIN' => 'Вход',
    'NAV_PROFILE' => 'Профиль',
    'NAV_LOGOUT' => 'Выход',
    'NAV_ADMIN' => 'Управление',
    'NAV_ADMIN_USERS' => 'Пользователи',
];