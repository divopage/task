<?php

return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=192.168.0.152;dbname=programcenter',
            'username' => 'root',
            'password' => '',
            'tablePrefix' => '',
        ],
        'mailer' => [
            'useFileTransport' => true,
        ],
    ],
];
 