<?php

return [
    'adminEmail' => '',
    'supportEmail' => '',
    'user.passwordResetTokenExpire' => 3600,
    'user.emailConfirmTokenExpire' => 3600 * 24 * 3,
    'user.defaultRole' => 'user',
];
