<?php

return [
    'TITLE_CONTACT' => 'Обратная связь',

    'BUTTON_SEND' => 'Отправить',

    'CONTACT_NAME' => 'Ваше имя',
    'CONTACT_EMAIL' => 'Ваш Email',
    'CONTACT_SUBJECT' => 'Тема',
    'CONTACT_MESSAGE' => 'Сообщение',
    'CONTACT_VERIFY_CODE' => 'Код',
    'CONTACT_THANKS' => 'Спасибо! Мы свяжемся с Вами в скором  времени.',
];