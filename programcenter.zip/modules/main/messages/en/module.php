<?php

return [
    'TITLE_CONTACT' => 'Contact',

    'BUTTON_SEND' => 'Send',

    'CONTACT_NAME' => 'Your name',
    'CONTACT_EMAIL' => 'Your Email',
    'CONTACT_SUBJECT' => 'Subject',
    'CONTACT_MESSAGE' => 'Message',
    'CONTACT_VERIFY_CODE' => 'Verify code',
    'CONTACT_THANKS' => 'Thank you for contacting us. We will respond to you as soon as possible.',
];