<?php

namespace app\modules\admin\rbac;

class Rbac
{
    const PERMISSION_ADMIN_PANEL = 'permAdminPanel';
}