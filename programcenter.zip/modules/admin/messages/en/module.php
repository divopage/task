<?php

return [
    'ADMIN' => 'Control panel',
];