<?php

return [
    'ADMIN' => 'Панель управления',
];